Hyperion Placements Full Stack Assessment
Written by Abdullah Mansuri

This website makes use of Node.js, Express web application framework, React and an SQLITE database.

In order to get the website working, please follow the following steps:

1. Install Node.js (Preferably 12.8.1 as it was coded using this version) https://nodejs.org/en/  .
2. The dependencies (node modules) need to be installed. Inside the "app-backend" folder, open a command prompt window with administritive rights and type "npm install".
3. The same (step number 2) should be done inside of the "frontend" folder.
4. There should be now a "node_modules" folder inside of the "app-backend" folder, and a "node_modules" folder inside of the "frontend" folder inside the "app-backend" folder.
5. This website is split into a backend and a frontend and both need to be running in order for the website to function.
6. In order to start the backend server, type "npm start" into an administritive command prompt window in the "app-backend" folder.
7. In order to start the frontend server, type "npm start" into an administritive command prompt window in the "frontend" folder which is found in the "app-backend" folder.
8. Any warnings can be ignored, if a module is missing, close the servers and type "npm install *module name*" and repeat from step 5.
9. The website should now automatically open in the default browser. It can also be opened at http://localhost:3000/

Thank you.