import React from 'react';
import { BrowserRouter , Route } from 'react-router-dom';
import HomeComponent from './components/HomeComponent';
import NavBarComponent from './components/NavBarComponent';
import ListComponent from './components/ListComponent';

function App() {
  return (
    <div className="App">
      
    <BrowserRouter>
          <div>
          
            <Route exact = {true} path = "/" component = {NavBarComponent} /> 
            <Route exact = {true} path = "/" component = {HomeComponent} />
            <Route exact = {true} path = "/all" component = {NavBarComponent} />
            <Route exact = {true} path = "/all" component = {ListComponent} />

          </div>
      </BrowserRouter>

    </div>
  );
}

export default App;
