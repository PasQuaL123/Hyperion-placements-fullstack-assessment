import React, { Component } from 'react';

class Header_Component extends Component{



  render() {
      return (
        <div>
        	
        </div>
      );
  }

}

export default Header_Component;