import React, { Component } from 'react';

class ListComponent extends Component{

	state = {Items: []}

	

	componentDidMount() {
  
	    fetch("/api/all").then(response => response.json()).then(data => this.setState({ Items: data }));


  	}	

  render() {


  		const ListOfItems = this.state.Items.map((d) =>
  			<div>
	  			<h4 id="messageheader"> {"Message: " + parseInt(d.ID + 1)} </h4>
	  			<div id="listitems" class="list-group">
		  			<a href="#" class="list-group-item list-group-item-action active">
		    			{"Full Name: " + d.FullName}
		  			</a>
					<a href="#" class="list-group-item list-group-item-action">{"Phone Number: " + d.PhoneNumber}</a>
					<a href="#" class="list-group-item list-group-item-action">{"Email: " + d.Email}</a>
					<a href="#" class="list-group-item list-group-item-action">{"Date : " + (new Date(d.DateTime).toString())}</a>
					<a href="#" class="list-group-item list-group-item-action">{"Message: " + d.Message}</a>
				</div>
			</div>
			);

 


      return (
        <div>
        	{ListOfItems}
        </div>
      );
  }

}

export default ListComponent;