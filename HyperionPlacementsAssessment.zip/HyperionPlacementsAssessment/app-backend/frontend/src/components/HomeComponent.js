import React, { Component } from 'react';

class HomeComponent extends Component{



  render() {
      return (
        <div>
        	<div class="alert alert-primary" role="alert">
  				Welcome, Please Fill In The Form Below To Add Your Message To The Database!
			</div>

			<form method="post" id ="frminput">

				<div class="form-group">
    				<label id="labelcolor" for="formGroupExampleInput">Full Name:</label>
    				<input required type="text" class="form-control" name="frminputfname" placeholder="Please Enter Your Full Name Here" />
  				</div>

  				<div class="form-group">
    				<label id="labelcolor" for="formGroupExampleInput">Phone Number:</label>
    				<input required type="text" class="form-control" name="frminputphone" placeholder="Please Enter Your Phone Number Here" />
  				</div>

	  			<div class="form-group">
	    			<label id="labelcolor" for="exampleFormControlInput1">Email Address:</label>
	    			<input required type="email" class="form-control" name="frminputemail" placeholder="Please Enter Your Email Address Here (name@example.com)" />
	  			</div>

  				<div class="form-group">
    				<label id="labelcolor" for="exampleFormControlTextarea1">Please Enter A Message Below: (Max 10,000 Characters)</label>
    				<textarea required maxlength="10000" class="form-control" name="frminputmessage" rows="3"></textarea>
  				</div>

  				<button type="submit" class="btn btn-light">Add To Database</button>
			</form>

        </div>
      );
  }

}

export default HomeComponent;

