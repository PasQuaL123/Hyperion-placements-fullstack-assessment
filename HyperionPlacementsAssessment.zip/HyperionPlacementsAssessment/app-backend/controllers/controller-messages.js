exports.DisplayAll = function(req, res, cb){
	
	var sqlite3 = require('sqlite3').verbose();
	const path = require('path');
	const dbPath = path.resolve(__dirname, './Messages.db');
	var db = new sqlite3.Database(dbPath);

	db.all('SELECT * FROM Message ORDER BY ID DESC', (err, results) => {
	  	if (err) {
	    	console.log(err);
	    	db.close();
	  	} else {
	  		res.send(results);
	  		db.close();
	  	}
	})
};

//Test function
exports.Test = function(req, res){

	res.writeHead(301, {Location: '/all'});
	response.end();

};

//Add message from the post
exports.AddMessage = function(req, res){

	var sFullName = req.body.frminputfname;
	var sPhone = req.body.frminputphone;
	var sEmail = req.body.frminputemail;
	var sMsg = req.body.frminputmessage;

	var arrMessage = sMsg.split("");
	var arrMessage = arrMessage.reverse();
	var sMsg = arrMessage.join("");

	var sFinalMsg = "";

	for (iLoop = 0; iLoop < sMsg.length; iLoop++){
		if (sMsg.charAt(iLoop).toUpperCase() != "E"){
			sFinalMsg += sMsg.charAt(iLoop);
		}
	}

	var sqlite3 = require('sqlite3').verbose();

	const path = require('path');
	const dbPath = path.resolve(__dirname, './Messages.db');
	var db = new sqlite3.Database(dbPath);

	var sDate = new Date().toISOString();

	//res.send('INSERT INTO Message VALUES ("' + sFullName + '", "' + sPhone + '", "' + sEmail + '", "' + sFinalMsg + '", "' + sDate + '")');

	var sSQL = 'INSERT INTO Message VALUES (' + null + ', "' + sFullName + '", "' + sPhone + '", "' + sEmail + '", "' + sFinalMsg + '", "' + sDate + '")';

	db.run(sSQL, function(err){
	 	if (err){
	 		console.log(err);
	 	}
	});

	//db.run("INSERT INTO Message VALUES (" + sFullName + ", " + sPhone + ", " + sEmail + ", " + sFinalMsg + ")");
	
	res.writeHead(301, {Location: '/all'});
	res.end();
};
