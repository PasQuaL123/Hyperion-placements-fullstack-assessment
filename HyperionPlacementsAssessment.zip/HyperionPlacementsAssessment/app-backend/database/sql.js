var sql = "CREATE TABLE Message (ID INTEGER PRIMARY KEY AUTOINCREMENT, FullName TEXT, PhoneNumber TEXT, Email TEXT, Message TEXT, DateTime TEXT)";

var sqlite3 = require('sqlite3').verbose();
var db = new sqlite3.Database('Messages.db');
var check;
db.serialize(function() {

  db.run(sql);
  sql = 'INSERT INTO Message VALUES (0, "Abdullah Mansuri", "0835758997", "abdullahspur@hotmail.com", "stnahpl ollH .dlrow ollH", "2019-08-16 23:36:00.000")';
 // var stmt = db.prepare('INSERT INTO Message VALUES (0, "Abdullah Mansuri", "0835758997", "abdullahspur@hotmail.com", "1337 Hello World Street", "stnahpl ollH .dlrow ollH")');
 // stmt.finalize();
  db.run(sql);
});

db.close();