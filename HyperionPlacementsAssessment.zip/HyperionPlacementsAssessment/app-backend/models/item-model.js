var mongoose = require ( 'mongoose' );

var ItemSchema = mongoose.Schema({

	ID: String,
	Name: String,
	HasOptions: Boolean,
	OPSize: String,
	OPColour: String,
	Price: String,

});

module.exports = mongoose.model('Item', ItemSchema, "Items");